
export interface LostItem {
  id: string;
  name: string;
  description: string;
  location: string;
  contact: string;
  dateFound: string;
  imageUrl: string;
}
