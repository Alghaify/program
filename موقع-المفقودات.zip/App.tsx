
import React, { useState, useMemo } from 'react';
import { LostItem } from './types';
import { INITIAL_ITEMS } from './constants';
import { ItemCard } from './components/ItemCard';
import { ReportFormModal } from './components/ReportFormModal';
import { SearchIcon, PlusIcon } from './components/icons';

const App: React.FC = () => {
  const [items, setItems] = useState<LostItem[]>(INITIAL_ITEMS);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleAddItem = (newItemData: Omit<LostItem, 'id' | 'dateFound' | 'imageUrl'>) => {
    const newItem: LostItem = {
      ...newItemData,
      id: new Date().getTime().toString(),
      dateFound: new Date().toISOString().split('T')[0],
      imageUrl: `https://picsum.photos/seed/${new Date().getTime()}/400/300`
    };
    setItems(prevItems => [newItem, ...prevItems]);
  };

  const filteredItems = useMemo(() => {
    if (!searchQuery) {
      return items;
    }
    const lowercasedQuery = searchQuery.toLowerCase();
    return items.filter(item =>
      item.name.toLowerCase().includes(lowercasedQuery) ||
      item.description.toLowerCase().includes(lowercasedQuery) ||
      item.location.toLowerCase().includes(lowercasedQuery)
    );
  }, [items, searchQuery]);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <header className="bg-white shadow-md sticky top-0 z-40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <h1 className="text-3xl font-bold text-teal-600">موقع المفقودات</h1>
            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 bg-teal-500 hover:bg-teal-600 text-white font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105"
            >
              <PlusIcon className="w-5 h-5"/>
              <span>إبلاغ عن مفقود</span>
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-10 text-center">
            <h2 className="text-4xl font-bold text-slate-800 mb-2">هل فقدت شيئاً؟</h2>
            <p className="text-lg text-slate-600">ابحث هنا أو أبلغ عن غرض وجدته لمساعدة الآخرين</p>
        </div>
      
        <div className="mb-12 max-w-2xl mx-auto">
          <div className="relative">
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none">
              <SearchIcon className="h-6 w-6 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="ابحث عن غرض مفقود (مثال: محفظة، مفاتيح، هاتف...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-12 pl-4 py-3 text-lg bg-white border-2 border-slate-200 rounded-full shadow-sm focus:ring-teal-500 focus:border-teal-500 transition"
            />
          </div>
        </div>

        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredItems.map(item => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-2xl text-slate-500">لا توجد نتائج مطابقة لبحثك.</p>
            <p className="text-slate-400 mt-2">حاول استخدام كلمات بحث مختلفة أو قم بإزالة البحث لعرض كل المفقودات.</p>
          </div>
        )}
      </main>

      <footer className="bg-slate-800 text-slate-300 mt-12 py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; {new Date().getFullYear()} موقع المفقودات. جميع الحقوق محفوظة.</p>
        </div>
      </footer>

      <ReportFormModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAddItem={handleAddItem}
      />
    </div>
  );
};

export default App;
