
import React, { useState } from 'react';
import { LostItem } from '../types';
import { XIcon } from './icons';

interface ReportFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddItem: (item: Omit<LostItem, 'id' | 'dateFound' | 'imageUrl'>) => void;
}

export const ReportFormModal: React.FC<ReportFormModalProps> = ({ isOpen, onClose, onAddItem }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [contact, setContact] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !description || !location || !contact) {
      setError('الرجاء تعبئة جميع الحقول.');
      return;
    }
    setError('');
    onAddItem({ name, description, location, contact });
    // Reset form and close modal
    setName('');
    setDescription('');
    setLocation('');
    setContact('');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 transition-opacity duration-300">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-lg relative transform transition-all duration-300 scale-95"
           onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 left-4 text-slate-400 hover:text-slate-600 transition-colors">
          <XIcon className="w-8 h-8" />
        </button>
        <h2 className="text-3xl font-bold text-center text-slate-800 mb-6">الإبلاغ عن غرض مفقود</h2>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">اسم الغرض</label>
            <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-teal-500 focus:border-teal-500" placeholder="مثال: هاتف آيفون" required />
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-1">وصف الغرض</label>
            <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-teal-500 focus:border-teal-500" placeholder="صف شكل الغرض، لونه، وأي علامات مميزة" required></textarea>
          </div>
          <div>
            <label htmlFor="location" className="block text-sm font-medium text-slate-700 mb-1">مكان العثور عليه</label>
            <input type="text" id="location" value={location} onChange={(e) => setLocation(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-teal-500 focus:border-teal-500" placeholder="مثال: الرياض، مول المملكة" required />
          </div>
          <div>
            <label htmlFor="contact" className="block text-sm font-medium text-slate-700 mb-1">معلومات التواصل (بريد إلكتروني أو رقم هاتف)</label>
            <input type="text" id="contact" value={contact} onChange={(e) => setContact(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-teal-500 focus:border-teal-500" placeholder="example@email.com أو 0501234567" required />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <div className="flex justify-end gap-4 pt-4">
            <button type="button" onClick={onClose} className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 transition-colors">إلغاء</button>
            <button type="submit" className="px-8 py-2 bg-teal-500 text-white font-semibold rounded-lg hover:bg-teal-600 transition-colors">إضافة البلاغ</button>
          </div>
        </form>
      </div>
    </div>
  );
};
