
import { LostItem } from './types';

export const INITIAL_ITEMS: LostItem[] = [
  {
    id: '1',
    name: 'محفظة جلدية بنية',
    description: 'محفظة رجالية تحتوي على بطاقات هوية وبطاقات بنكية. فقدت بالقرب من المركز التجاري.',
    location: 'الرياض، مول المملكة',
    contact: 'contact@example.com',
    dateFound: new Date('2024-07-20').toISOString().split('T')[0],
    imageUrl: 'https://picsum.photos/seed/wallet/400/300'
  },
  {
    id: '2',
    name: 'مفاتيح سيارة تويوتا',
    description: 'مجموعة مفاتيح مع ميدالية فضية صغيرة. وجدت في مواقف حديقة الملك عبدالله.',
    location: 'جدة، حديقة الملك عبدالله',
    contact: '0501234567',
    dateFound: new Date('2024-07-22').toISOString().split('T')[0],
    imageUrl: 'https://picsum.photos/seed/keys/400/300'
  },
  {
    id: '3',
    name: 'هاتف آيفون 14 برو',
    description: 'هاتف آيفون 14 برو أزرق اللون مع غطاء شفاف. وجد في مقهى ستاربكس.',
    location: 'الدمام، ستاربكس الشاطئ',
    contact: 'finder@email.com',
    dateFound: new Date('2024-07-23').toISOString().split('T')[0],
    imageUrl: 'https://picsum.photos/seed/iphone/400/300'
  },
  {
    id: '4',
    name: 'نظارة شمسية Ray-Ban',
    description: 'نظارة سوداء كلاسيكية. وجدت على أحد مقاعد الواجهة البحرية.',
    location: 'الخبر، الواجهة البحرية',
    contact: '0559876543',
    dateFound: new Date('2024-07-21').toISOString().split('T')[0],
    imageUrl: 'https://picsum.photos/seed/glasses/400/300'
  }
];
