
import React from 'react';
import { LostItem } from '../types';
import { LocationPinIcon, CalendarIcon } from './icons';

interface ItemCardProps {
  item: LostItem;
}

export const ItemCard: React.FC<ItemCardProps> = ({ item }) => {
  const isEmail = item.contact.includes('@');
  const contactLink = isEmail ? `mailto:${item.contact}` : `tel:${item.contact}`;

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300 ease-in-out flex flex-col">
      <img className="w-full h-48 object-cover" src={item.imageUrl} alt={item.name} />
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-2xl font-bold text-slate-900 mb-2">{item.name}</h3>
        <p className="text-slate-600 mb-4 flex-grow">{item.description}</p>
        <div className="space-y-3 text-sm mb-6">
            <div className="flex items-center text-slate-500">
                <LocationPinIcon className="w-5 h-5 me-2 text-teal-500" />
                <span>مكان العثور: {item.location}</span>
            </div>
            <div className="flex items-center text-slate-500">
                <CalendarIcon className="w-5 h-5 me-2 text-teal-500" />
                <span>تاريخ العثور: {item.dateFound}</span>
            </div>
        </div>
        <div className="mt-auto">
            <a href={contactLink} className="w-full text-center block bg-teal-500 hover:bg-teal-600 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300">
                تواصل مع المُبلغ
            </a>
        </div>
      </div>
    </div>
  );
};
